﻿Public Class Form1

    Public b As Bitmap
    Public g As Graphics
    Public SmallFont As New Font("Calibri", 10, FontStyle.Regular, GraphicsUnit.Pixel)

    'viewport'
    Public Viewport As New Rectangle(400, 50, 500, 500)

    'dataset'
    Public DataSet As DataSet

    'window'
    Public MinX_Window As Double = -250
    Public MaxX_Window As Double = 250
    Public MinY_Window As Double = -250
    Public MaxY_WIndow As Double = 250
    Public RangeX As Double = MaxX_Window - MinX_Window
    Public RangeY As Double = MaxY_WIndow - MinY_Window

    Sub InitializeGraphics()
        Me.b = New Bitmap(Me.PictureBox1.Width, Me.PictureBox1.Height)
        Me.g = Graphics.FromImage(b)
        Me.g.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias
        Me.g.TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAlias
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Me.InitializeGraphics()

        '----------------------------------------'

        Me.DataSet = New DataSet

        For i As Integer = -5 To 5
            For j As Integer = -5 To 5
                Dim DataPoint As New DataPoint
                DataPoint.X = i * 50
                DataPoint.Y = j * 50
                DataSet.DataPoints.Add(DataPoint)
            Next
        Next

        '-------------------------------------------'

        Me.RichTextBox1.Clear()
        For Each d As DataPoint In DataSet.DataPoints
            Me.RichTextBox1.AppendText(vbCrLf)
            Me.RichTextBox1.AppendText(d.X.ToString.PadRight(10) & d.Y.ToString.PadRight(10))
        Next

        DrawScene()

    End Sub


    'updating the draw'
    Sub DrawScene()

        g.Clear(Color.White)
        Me.g.DrawRectangle(Pens.Green, Viewport)

        'transform and prints the points'
        For Each d As DataPoint In DataSet.DataPoints

            Dim X_Device As Integer = Me.X_Viewport(d.X, Viewport, MinX_Window, RangeX)
            Dim Y_Device As Integer = Me.Y_Viewport(d.Y, Viewport, MinY_Window, RangeY)

            g.FillEllipse(Brushes.Blue, New Rectangle(New Point(X_Device - 3, Y_Device - 3), New Size(6, 6)))
            g.DrawString(d.X.ToString & ",." & d.Y.ToString, SmallFont, Brushes.Red, New Point(X_Device, Y_Device))
        Next

        Me.PictureBox1.Image = b

    End Sub




    '==========================================================================================================='
    'MANUAL TRANSFORMATION'

    'X to x transformation'
    Function X_Viewport(X_World As Double, Viewport As Rectangle, MinX As Double, RangeX As Double) As Integer

        Return CInt(Viewport.Left + Viewport.Width * (X_World - MinX) / RangeX)

    End Function

    'Y to y transformation'
    Function Y_Viewport(Y_World As Double, Viewport As Rectangle, MinY As Double, RangeY As Double) As Integer

        Return CInt(Viewport.Top + Viewport.Height - Viewport.Height * (Y_World - MinY) / RangeY)

    End Function
    '==========================================================================================================='





    '==========================================================================================================='
    'MOUSE HANDLERS'

    Private Viewport_At_Mouse_Down As Rectangle
    Private MouseLocation_At_MouseDown As Point
    Private Dragging_Started As Boolean
    Private Resizing_Started As Boolean

    Private Sub PictureBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseDown



        If Me.Viewport.Contains(e.X, e.Y) Then
            Me.Viewport_At_Mouse_Down = Me.Viewport
            MouseLocation_At_MouseDown = New Point(e.X, e.Y)

            If e.Button = Windows.Forms.MouseButtons.Left Then
                Me.Dragging_Started = True
            ElseIf e.Button = Windows.Forms.MouseButtons.Right Then
                Me.Resizing_Started = True
            End If

        End If

    End Sub

    Private Sub PictureBox1_MouseMove(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseMove

        If Me.Dragging_Started Then

            Dim Delta_X As Integer = e.X - Me.MouseLocation_At_MouseDown.X
            Dim Delta_Y As Integer = e.Y - Me.MouseLocation_At_MouseDown.Y

            Me.Viewport.X = Me.MouseLocation_At_MouseDown.X + Delta_X
            Me.Viewport.Y = Me.MouseLocation_At_MouseDown.Y + Delta_Y

            Me.DrawScene()

        ElseIf Me.Resizing_Started Then

            Dim Delta_X As Integer = e.X - Me.MouseLocation_At_MouseDown.X
            Dim Delta_Y As Integer = e.Y - Me.MouseLocation_At_MouseDown.Y

            Me.Viewport.Width = Me.Viewport_At_Mouse_Down.Width + Delta_X
            Me.Viewport.Height = Me.Viewport_At_Mouse_Down.Height + Delta_Y

            Me.DrawScene()

        End If

    End Sub

    Private Sub PictureBox1_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseUp

        Me.Dragging_Started = False
        Me.Resizing_Started = False

    End Sub

    Private Sub PictureBox1_MouseWheel(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseWheel

        Dim Change_X As Integer = 40 'CInt(Me.Viewport.Width / 10)'
        Dim Change_Y As Integer = CInt(Viewport.Height * Change_X / Me.Viewport.Width)

        If e.Delta > 0 Then

            Me.Viewport.X -= Change_X
            Me.Viewport.Width += 2 * Change_X

            Me.Viewport.Y -= Change_Y
            Me.Viewport.Height += 2 * Change_Y

            DrawScene()

        ElseIf e.Delta < 0 Then

            Me.Viewport.X += Change_X
            Me.Viewport.Width -= 2 * Change_X

            Me.Viewport.Y += Change_Y
            Me.Viewport.Height -= 2 * Change_Y

            DrawScene()

        End If

    End Sub

    Private Sub PictureBox1_MouseEnter(sender As Object, e As EventArgs) Handles PictureBox1.MouseEnter
        Me.PictureBox1.Focus()
    End Sub

    '==========================================================================================================='


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Application.CurrentCulture = Globalization.CultureInfo.InvariantCulture
    End Sub

End Class

Public Class DataSet
    Public DataPoints As New List(Of DataPoint)
End Class

Public Class DataPoint
    Public X As Double
    Public Y As Double
End Class